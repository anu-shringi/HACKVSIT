package com.example.pollutionpreventionsystem;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
