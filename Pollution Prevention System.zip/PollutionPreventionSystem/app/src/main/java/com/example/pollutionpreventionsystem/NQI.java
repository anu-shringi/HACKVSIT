package com.example.pollutionpreventionsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NQI extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nqi);
    }
}
